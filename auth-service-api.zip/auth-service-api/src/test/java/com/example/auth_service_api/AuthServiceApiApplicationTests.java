package com.example.auth_service_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthServiceApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
